//Attach plugin to slideshow with ".gallery-slideshow" class
$(function() {
  $('.gallery-slideshow').slideshow({
    interval: 2000,
    width: 600,
    height: 450
  });
});
